package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;

public class WebPomRegistration {
	
	static WebDriver driver ;
	public static WebDriver getWebDriver()
	{
		driver=  WebUtil.getWebDriver();
		return driver;
	}
	public static WebElement getFullNameField() {
		return driver.findElement(By.id("txtFullName"));

	}
	public static WebElement getEmailField() {
		return driver.findElement(By.id("txtEmail"));

	}
	public static WebElement getPhoneNoField() {
		return driver.findElement(By.id("txtPhone"));

	}
	/*public static WebElement getGenderField() {
		return driver.findElement(By.id("txtFullName"));

	}*/
	public static WebElement getCityField() {
		return driver.findElement(By.name("city"));

	}
	public static WebElement getStateField() {
		return driver.findElement(By.name("state"));

	}
	public static WebElement getSubjectCategoryField() {
		return driver.findElement(By.id("txtCardholderName"));

	}
	public static WebElement getPaperNameField() {
		return driver.findElement(By.id("txtDebit"));

	}
	public static WebElement getAuthorField() {
		return driver.findElement(By.id("txtCvv"));

	}
	public static WebElement getCompanyNameField() {
		return driver.findElement(By.id("txtMonth"));

	}
	public static WebElement getDesignationField() {
		return driver.findElement(By.id("txtYear"));

	}
	public static WebElement submitButton() {
		return driver.findElement(By.id("btnPayment"));

	}
	
}