package com.capg.stepdefinition;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.WebUtil;
import com.capg.pom.WebPom;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginStepdefinition {
	WebDriver driver;

	@Given("^Navigate to Login page url$")
	public void navigate_to_Login_page_url() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
        driver=WebPom.getWebDriver();
        String url="C:\\Users\\dchundru\\Desktop\\VV AT M4_MPT Sample Que\\login.html";
        driver.get(url);
        
	}

	@When("^User enters valid username \"([^\"]*)\" and valid password \"([^\"]*)\"$")
	public void user_enters_valid_username_and_valid_password(String username, String password) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 WebElement userTextField = WebPom.getUserField();
		 	WebElement passwordTextField = WebPom.getPasswordField();
		 	userTextField.sendKeys(username);
		 	passwordTextField.sendKeys(password);
		
		
		
		
	}

	@Then("^Login successfully$")
	public void login_successfully() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    WebElement loginButton=WebPom.getLoginButton();
	    loginButton.click();
	}


	
	
}
