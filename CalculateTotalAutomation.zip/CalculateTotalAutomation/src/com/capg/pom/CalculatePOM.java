package com.capg.pom;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CalculatePOM {

	
	static WebDriver driver;
	public static WebDriver getWebDriver()
	{
		driver=WebUtil.getWebDriver();
		return driver;
	}
	
	public static WebElement getPrice()
	{
		return driver.findElement(By.name("price"));
		
	}
	public static WebElement getQuantity()
	{
		return driver.findElement(By.name("quantity"));
		
	}
	public static WebElement getButton()
	{
		return driver.findElement(By.id("btn"));
		
	}
}
