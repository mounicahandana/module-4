package com.capg.stepdefinition;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.capg.pom.CalculatePOM;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class stepDefinition {
	WebDriver driver;
	@Given("^Open Any Browser and Enter URL$")
	public void open_Any_Browser_and_Enter_URL() throws Throwable {
		driver=CalculatePOM.getWebDriver();
		String url = "C:\\BDDDemo\\CalculateTotalAutomation\\html\\demo.html";
		driver.get(url);
	}

	
	@When("^User Enter the price \"([^\"]*)\"   and quantity \"([^\"]*)\"$")
	public void user_Enter_the_price_and_quantity(String prices, String quant) throws Throwable {
		 WebElement price=CalculatePOM.getPrice();
		   price.sendKeys(prices);
		   WebElement quantity=CalculatePOM.getQuantity();
		   quantity.sendKeys(quant);
	}
	

	@When("^User Enter less price \"([^\"]*)\"   and quantity \"([^\"]*)\"$")
	public void user_Enter_less_price_and_quantity(String prices, String quant) throws Throwable {
		 WebElement price=CalculatePOM.getPrice();
		   price.sendKeys(prices);
		   WebElement quantity=CalculatePOM.getQuantity();
		   quantity.sendKeys(quant);
	}

	
	@Then("^Display Total$")
	public void display_Total() throws Throwable {
	   WebElement btn=CalculatePOM.getButton();
	   btn.click();
	   driver.switchTo().alert().accept();
	   driver.close();
	}
	
	@Then("^Display alert$")
	public void display_alert() throws Throwable {
		WebElement btn=CalculatePOM.getButton();
		btn.click();
	    driver.switchTo().alert().accept();
	    driver.close();
	    
	}
}
